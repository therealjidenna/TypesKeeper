# Keep Room entities
-keep class com.therealjidenna.typekeeper.data.** { *; }
