package com.therealjidenna.typekeeper.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.text.format.DateFormat
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.therealjidenna.typekeeper.data.AppSummary
import com.therealjidenna.typekeeper.data.TypedEntry
import java.util.Date

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    TypeKeeperApp()
                }
            }
        }
    }
}

private sealed class Screen {
    object AppList : Screen()
    data class AppEntries(val app: AppSummary) : Screen()
    object SettingsScreen : Screen()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TypeKeeperApp(vm: MainViewModel = viewModel()) {
    val context = LocalContextCompat()
    var screen by remember { mutableStateOf<Screen>(Screen.AppList) }
    var query by remember { mutableStateOf("") }
    var showSearch by remember { mutableStateOf(false) }

    val apps by vm.apps.collectAsState(initial = emptyList())
    val entries by vm.entries.collectAsState(initial = emptyList())
    val searchResults by vm.searchResults.collectAsState(initial = emptyList())
    val serviceEnabled by vm.serviceEnabled.collectAsState(initial = false)

    LaunchedEffect(screen) {
        if (screen is Screen.AppEntries) {
            vm.loadEntriesForApp((screen as Screen.AppEntries).app.packageName)
        }
    }
    LaunchedEffect(query) {
        if (query.isNotBlank()) vm.search(query)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    when (val s = screen) {
                        is Screen.AppEntries -> Text(s.app.appLabel)
                        Screen.SettingsScreen -> Text("Settings")
                        else -> Text("TypeKeeper")
                    }
                },
                navigationIcon = {
                    if (screen !is Screen.AppList) {
                        IconButton(onClick = {
                            showSearch = false
                            query = ""
                            screen = Screen.AppList
                        }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                        }
                    }
                },
                actions = {
                    if (screen is Screen.AppList) {
                        IconButton(onClick = { showSearch = !showSearch }) {
                            Icon(Icons.Default.Search, contentDescription = "Search")
                        }
                        IconButton(onClick = { screen = Screen.SettingsScreen }) {
                            Icon(Icons.Default.Settings, contentDescription = "Settings")
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {

            if (!serviceEnabled && screen is Screen.AppList) {
                EnableServiceBanner(onEnable = {
                    context.startActivity(Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS))
                })
            }

            if (showSearch && screen is Screen.AppList) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("Search saved text") },
                    modifier = Modifier.fillMaxWidth().padding(16.dp)
                )
            }

            when (val s = screen) {
                Screen.AppList -> {
                    if (showSearch && query.isNotBlank()) {
                        EntryList(entries = searchResults, onDelete = { vm.delete(it) })
                    } else {
                        AppListView(apps = apps, onClick = { screen = Screen.AppEntries(it) })
                    }
                }
                is Screen.AppEntries -> {
                    EntryList(entries = entries, onDelete = { vm.delete(it) })
                }
                Screen.SettingsScreen -> {
                    SettingsView(vm)
                }
            }
        }
    }
}

@Composable
private fun EnableServiceBanner(onEnable: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(
                "TypeKeeper isn't active yet",
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onErrorContainer
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "Turn on the Accessibility Service so TypeKeeper can start saving your typing.",
                color = MaterialTheme.colorScheme.onErrorContainer
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = onEnable) { Text("Open Settings") }
        }
    }
}

@Composable
private fun AppListView(apps: List<AppSummary>, onClick: (AppSummary) -> Unit) {
    if (apps.isEmpty()) {
        EmptyState("Nothing saved yet. Start typing in any app and it will show up here.")
        return
    }
    LazyColumn {
        items(apps) { app ->
            ListItem(
                headlineContent = { Text(app.appLabel) },
                supportingContent = { Text(app.packageName) },
                modifier = Modifier.clickable { onClick(app) }
            )
            HorizontalDivider()
        }
    }
}

@Composable
private fun EntryList(entries: List<TypedEntry>, onDelete: (TypedEntry) -> Unit) {
    val context = LocalContextCompat()
    if (entries.isEmpty()) {
        EmptyState("No entries here yet.")
        return
    }
    LazyColumn {
        items(entries, key = { it.id }) { entry ->
            Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text(
                        DateFormat.format("MMM d, h:mm a", Date(entry.timestamp)).toString()
                            + if (entry.source.name == "CLIPBOARD") "  •  copied" else "  •  typed",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(entry.text, style = MaterialTheme.typography.bodyMedium)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        IconButton(onClick = {
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("TypeKeeper", entry.text))
                        }) { Icon(Icons.Default.ContentCopy, contentDescription = "Copy") }
                        IconButton(onClick = {
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, entry.text)
                            }
                            context.startActivity(Intent.createChooser(send, null))
                        }) { Icon(Icons.Default.Share, contentDescription = "Share") }
                        IconButton(onClick = { onDelete(entry) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsView(vm: MainViewModel) {
    val enabled by vm.globalEnabled.collectAsState(initial = true)
    val clipboardEnabled by vm.clipboardEnabledFlow.collectAsState(initial = true)
    val retention by vm.retentionDaysFlow.collectAsState(initial = 14)

    Column(Modifier.padding(16.dp)) {
        SettingsSwitchRow(
            title = "Save typing",
            subtitle = "Master switch for saving text you type across apps",
            checked = enabled,
            onCheckedChange = { vm.setGlobalEnabled(it) }
        )
        SettingsSwitchRow(
            title = "Save clipboard copies",
            subtitle = "Also save text you copy to the clipboard",
            checked = clipboardEnabled,
            onCheckedChange = { vm.setClipboardEnabled(it) }
        )
        Spacer(Modifier.height(16.dp))
        Text("Auto-delete after", fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) {
            listOf(7, 14, 30, 0).forEach { days ->
                FilterChip(
                    selected = retention == days,
                    onClick = { vm.setRetentionDays(days) },
                    label = { Text(if (days == 0) "Never" else "$days days") },
                    modifier = Modifier.padding(end = 8.dp, top = 8.dp)
                )
            }
        }
        Spacer(Modifier.height(24.dp))
        OutlinedButton(onClick = { vm.clearAll() }) {
            Text("Delete all saved entries")
        }
    }
}

@Composable
private fun SettingsSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun EmptyState(message: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(message, modifier = Modifier.padding(32.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
    }
}

@Composable
private fun LocalContextCompat(): Context = androidx.compose.ui.platform.LocalContext.current
