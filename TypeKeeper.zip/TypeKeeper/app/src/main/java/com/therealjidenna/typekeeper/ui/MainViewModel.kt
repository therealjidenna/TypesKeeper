package com.therealjidenna.typekeeper.ui

import android.app.Application
import android.text.TextUtils
import android.provider.Settings as AndroidSettings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.therealjidenna.typekeeper.data.AppDatabase
import com.therealjidenna.typekeeper.data.AppSummary
import com.therealjidenna.typekeeper.data.Settings
import com.therealjidenna.typekeeper.data.TypedEntry
import com.therealjidenna.typekeeper.service.TypeKeeperAccessibilityService
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val db = AppDatabase.get(app)
    private val settings = Settings(app)

    val apps: Flow<List<AppSummary>> = db.entryDao().observeApps()

    private val _entries = MutableStateFlow<List<TypedEntry>>(emptyList())
    val entries: StateFlow<List<TypedEntry>> = _entries

    private val _searchResults = MutableStateFlow<List<TypedEntry>>(emptyList())
    val searchResults: StateFlow<List<TypedEntry>> = _searchResults

    private val _globalEnabled = MutableStateFlow(settings.globalEnabled)
    val globalEnabled: StateFlow<Boolean> = _globalEnabled

    private val _clipboardEnabledFlow = MutableStateFlow(settings.clipboardEnabled)
    val clipboardEnabledFlow: StateFlow<Boolean> = _clipboardEnabledFlow

    private val _retentionDaysFlow = MutableStateFlow(settings.retentionDays)
    val retentionDaysFlow: StateFlow<Int> = _retentionDaysFlow

    val serviceEnabled: Flow<Boolean> = flow {
        emit(isAccessibilityServiceEnabled())
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val context = getApplication<Application>()
        val expected = "${context.packageName}/${TypeKeeperAccessibilityService::class.java.name}"
        val enabledServices = AndroidSettings.Secure.getString(
            context.contentResolver,
            AndroidSettings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabledServices)
        while (splitter.hasNext()) {
            if (splitter.next().equals(expected, ignoreCase = true)) return true
        }
        return false
    }

    fun loadEntriesForApp(packageName: String) {
        viewModelScope.launch {
            db.entryDao().observeForApp(packageName).collect { _entries.value = it }
        }
    }

    fun search(query: String) {
        viewModelScope.launch {
            db.entryDao().search(query).collect { _searchResults.value = it }
        }
    }

    fun delete(entry: TypedEntry) {
        viewModelScope.launch { db.entryDao().delete(entry.id) }
    }

    fun clearAll() {
        viewModelScope.launch { db.entryDao().deleteAll() }
    }

    fun setGlobalEnabled(enabled: Boolean) {
        settings.globalEnabled = enabled
        _globalEnabled.value = enabled
    }

    fun setClipboardEnabled(enabled: Boolean) {
        settings.clipboardEnabled = enabled
        _clipboardEnabledFlow.value = enabled
    }

    fun setRetentionDays(days: Int) {
        settings.retentionDays = days
        _retentionDaysFlow.value = days
        if (days > 0) {
            val cutoff = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(days.toLong())
            viewModelScope.launch { db.entryDao().deleteOlderThan(cutoff) }
        }
    }
}
