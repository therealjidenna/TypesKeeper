package com.therealjidenna.typekeeper.data

import android.content.Context

/**
 * Lightweight settings store backed by SharedPreferences.
 * Keeps the list of disabled (opted-out) app package names and the
 * retention window (days) for auto-deleting old entries.
 */
class Settings(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("typekeeper_settings", Context.MODE_PRIVATE)

    var globalEnabled: Boolean
        get() = prefs.getBoolean("global_enabled", true)
        set(value) = prefs.edit().putBoolean("global_enabled", value).apply()

    var retentionDays: Int
        get() = prefs.getInt("retention_days", 14)
        set(value) = prefs.edit().putInt("retention_days", value).apply()

    var clipboardEnabled: Boolean
        get() = prefs.getBoolean("clipboard_enabled", true)
        set(value) = prefs.edit().putBoolean("clipboard_enabled", value).apply()

    private fun disabledSet(): MutableSet<String> =
        HashSet(prefs.getStringSet("disabled_packages", emptySet()) ?: emptySet())

    fun isAppEnabled(packageName: String): Boolean =
        !disabledSet().contains(packageName)

    fun setAppEnabled(packageName: String, enabled: Boolean) {
        val set = disabledSet()
        if (enabled) set.remove(packageName) else set.add(packageName)
        prefs.edit().putStringSet("disabled_packages", set).apply()
    }

    // Apps we never want to log by default: keyboards, password managers, banking-ish.
    companion object {
        val ALWAYS_EXCLUDED = setOf(
            "com.therealjidenna.typekeeper"
        )
    }
}
