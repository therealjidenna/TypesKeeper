package com.therealjidenna.typekeeper.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface EntryDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entry: TypedEntry)

    @Query("SELECT * FROM entries ORDER BY timestamp DESC")
    fun observeAll(): Flow<List<TypedEntry>>

    @Query("SELECT * FROM entries WHERE packageName = :packageName ORDER BY timestamp DESC")
    fun observeForApp(packageName: String): Flow<List<TypedEntry>>

    @Query("SELECT DISTINCT packageName, appLabel FROM entries")
    fun observeApps(): Flow<List<AppSummary>>

    @Query("SELECT * FROM entries WHERE text LIKE '%' || :query || '%' ORDER BY timestamp DESC")
    fun search(query: String): Flow<List<TypedEntry>>

    @Query("DELETE FROM entries WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM entries")
    suspend fun deleteAll()

    @Query("DELETE FROM entries WHERE timestamp < :cutoff")
    suspend fun deleteOlderThan(cutoff: Long)
}

data class AppSummary(
    val packageName: String,
    val appLabel: String
)
