package com.therealjidenna.typekeeper.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class EntrySource { TYPED, CLIPBOARD }

@Entity(tableName = "entries")
data class TypedEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val packageName: String,
    val appLabel: String,
    val text: String,
    val timestamp: Long,
    val source: EntrySource
)
