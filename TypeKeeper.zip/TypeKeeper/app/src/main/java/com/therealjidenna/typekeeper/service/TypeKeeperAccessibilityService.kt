package com.therealjidenna.typekeeper.service

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import com.therealjidenna.typekeeper.data.AppDatabase
import com.therealjidenna.typekeeper.data.EntrySource
import com.therealjidenna.typekeeper.data.Settings
import com.therealjidenna.typekeeper.data.TypedEntry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Watches text-field changes system-wide and stores the final text per field
 * (debounced), plus clipboard copy events. Skips password fields and any
 * app the user has opted out of.
 */
class TypeKeeperAccessibilityService : AccessibilityService() {

    private val job = Job()
    private val scope = CoroutineScope(Dispatchers.IO + job)
    private val mainHandler = Handler(Looper.getMainLooper())

    private lateinit var db: AppDatabase
    private lateinit var settings: Settings
    private lateinit var clipboardManager: ClipboardManager

    // packageName+viewId -> pending debounce runnable
    private val pendingSaves = HashMap<String, Runnable>()
    private val lastClipText = StringBuilder()

    private var clipboardListener: ClipboardManager.OnPrimaryClipChangedListener? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        db = AppDatabase.get(applicationContext)
        settings = Settings(applicationContext)
        clipboardManager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager

        clipboardListener = ClipboardManager.OnPrimaryClipChangedListener {
            if (!settings.globalEnabled || !settings.clipboardEnabled) return@OnPrimaryClipChangedListener
            handleClipboardChange()
        }
        clipboardManager.addPrimaryClipChangedListener(clipboardListener)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        if (!settings.globalEnabled) return

        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return // never log ourselves
        if (!settings.isAppEnabled(pkg)) return

        when (event.eventType) {
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> handleTextChanged(event, pkg)
            else -> Unit
        }
    }

    private fun handleTextChanged(event: AccessibilityEvent, pkg: String) {
        val source = event.source
        if (source != null && source.isPassword) return

        val text = event.text?.joinToString(separator = "")?.trim().orEmpty()
        if (text.isEmpty()) return

        val key = "$pkg:${event.className}"
        pendingSaves[key]?.let { mainHandler.removeCallbacks(it) }

        val runnable = Runnable {
            saveEntry(pkg, text, EntrySource.TYPED)
            pendingSaves.remove(key)
        }
        pendingSaves[key] = runnable
        // Debounce: only persist once typing pauses for 1.2s
        mainHandler.postDelayed(runnable, 1200)
    }

    private fun handleClipboardChange() {
        val clip: ClipData? = clipboardManager.primaryClip
        val text = clip?.getItemAt(0)?.coerceToText(this)?.toString()?.trim()
        if (text.isNullOrEmpty()) return
        if (text == lastClipText.toString()) return
        lastClipText.clear()
        lastClipText.append(text)

        // Clipboard events don't reliably report the source package on all OEMs,
        // so we attribute them to "Clipboard" rather than guessing the app.
        saveEntry("clipboard", text, EntrySource.CLIPBOARD, appLabelOverride = "Clipboard")
    }

    private fun saveEntry(
        pkg: String,
        text: String,
        source: EntrySource,
        appLabelOverride: String? = null
    ) {
        val label = appLabelOverride ?: resolveAppLabel(pkg)
        scope.launch {
            db.entryDao().insert(
                TypedEntry(
                    packageName = pkg,
                    appLabel = label,
                    text = text,
                    timestamp = System.currentTimeMillis(),
                    source = source
                )
            )
        }
    }

    private fun resolveAppLabel(pkg: String): String = try {
        val pm = packageManager
        val info = pm.getApplicationInfo(pkg, 0)
        pm.getApplicationLabel(info).toString()
    } catch (e: Exception) {
        pkg
    }

    override fun onInterrupt() { /* no-op */ }

    override fun onDestroy() {
        super.onDestroy()
        clipboardListener?.let { clipboardManager.removePrimaryClipChangedListener(it) }
        job.cancel()
    }
}
