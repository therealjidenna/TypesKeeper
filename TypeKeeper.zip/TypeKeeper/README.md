# TypeKeeper

An offline, on-device "never lose what you typed" app for Android.
It saves text you type in other apps (and things you copy), grouped by app,
so you can recover it if a note, message, or form gets closed or crashed
before you saved it. Everything stays on your phone — no internet, no
cloud, nothing leaves the device.

## How it works
- An Accessibility Service watches text-field changes and clipboard copies.
- Text is debounced (saved once you pause typing) and stored locally in a
  Room (SQLite) database.
- Password fields are never captured.
- You can disable specific apps, turn off clipboard capture, and set
  auto-delete after 7/14/30 days or never.

## Building the APK via GitHub Actions
1. Push this code to a repo (e.g. `TypeKeeper`).
2. GitHub Actions (`.github/workflows/build.yml`) builds a debug APK on every
   push to `main`, or you can trigger it manually from the **Actions** tab
   ("Run workflow").
3. Open the finished run, scroll to **Artifacts**, and download
   `TypeKeeper-debug-apk`. Unzip it to get `app-debug.apk`.
4. Transfer/open that APK on your Android phone and install it
   (you may need to allow "install unknown apps" for your browser/files app).

## After installing
Open TypeKeeper, tap **Open Settings** on the banner, and turn on the
TypeKeeper accessibility service. That's the one manual step Android
requires for this kind of app to work.
